package com.banana.bananamint.exception;

public class IncomeExpenseException extends RuntimeException{
    public IncomeExpenseException() {
    }

    public IncomeExpenseException(String message) {
        super(message);
    }
}
